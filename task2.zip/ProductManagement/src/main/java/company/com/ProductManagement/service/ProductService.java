package company.com.ProductManagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import company.com.ProductManagement.Dao.ProductDao;
import company.com.ProductManagement.model.Product;

@Service
public class ProductService {

	@Autowired
	ProductDao pd;
	
	public double getDiscount( Product pr , double discount ) {
		int price = pr.getPrice();	
		double desc = price * discount / 100;
		pr.setDiscount(discount);
		return desc;
	}
	
	public double  getTax(Product pr , double tax) {
		int price = pr.getPrice();
		double tax2 = price * tax / 100;
		pr.setTax(tax);
		return tax2;
	}
	
	public void setTotalAmount(Product pr , double tax , double discount) {
		pr.setTotalPrice(pr.getTotalPrice()-discount + tax);
	}
	
	public void updateAmount(Product pr) {
		String catagory = pr.getCatagory();
		
		switch(catagory) {
		case "electronic":
			double discount = getDiscount(pr , 20);
			double tax = getTax(pr, 28);
			setTotalAmount(pr , discount ,tax);
			break;
			
		case "home":
			double discount2 = getDiscount(pr , 30);
			double tax2 = getTax(pr, 20);
			setTotalAmount(pr , discount2 ,tax2);
			break;
			
		case "stationary":
			double discount3 = getDiscount(pr , 30);
			double tax3 = getTax(pr, 20);
			setTotalAmount(pr , discount3 ,tax3);
			break;
		}
	}
	
	
	public List<Product> getAllProduct(){
		
		List<Product> allProduct = pd.getAllProducts();
		
		allProduct.stream().forEach(product -> updateAmount(product));
		
		return allProduct;
	}
	
}
