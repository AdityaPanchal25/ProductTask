package company.com.ProductManagement.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Product{

	@Id
	private int id;
	private int price;
	private String name;
	private String catagory;
	
	private double totalPrice;
	
	private double discount;
	private double tax;
	
	
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	public double getTax() {
		return tax;
	}
	public void setTax(double tax) {
		this.tax = tax;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCatagory() {
		return catagory;
	}
	public void setCatagory(String catagory) {
		this.catagory = catagory;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", price=" + price + ", name=" + name + ", catagory=" + catagory + ", totalPrice="
				+ totalPrice + ", discount=" + discount + ", tax=" + tax + "]";
	}
	
	
	
	
}
