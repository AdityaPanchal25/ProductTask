package company.com.ProductManagement.config;

import java.sql.Connection;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import company.com.ProductManagement.model.Product;

@Component
public class Config {

	@Autowired
	SessionFactory sf;
	
public Session getSession() {
		
//		Configuration cfg = new Configuration();
//		System.err.println("configuration class called");
//		
//		Configuration cf = cfg.configure();
//		System.err.println("read xml file by configure");
//		
//		cf.addAnnotatedClass(Product.class);
//		System.err.println("annotated  class maped");
//		
//		SessionFactory sf = cfg.buildSessionFactory();
//		System.out.println("session factory build complete");
		
		Session ses = sf.openSession();
		
		return ses;
		
	}
	
}
