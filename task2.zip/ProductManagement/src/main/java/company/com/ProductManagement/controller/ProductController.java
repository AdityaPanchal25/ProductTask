package company.com.ProductManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import company.com.ProductManagement.model.Product;
import company.com.ProductManagement.service.ProductService;

@RestController
public class ProductController {

	@Autowired
	ProductService prs;
	
	@RequestMapping("check")
	public String tocheck() {
		return "hello";
	}
	
	@RequestMapping("getProducts")
	public List<Product> getAllProducts(){
		
		List<Product> allProduct = prs.getAllProduct();
		
		return allProduct;
	}
	
	
}
