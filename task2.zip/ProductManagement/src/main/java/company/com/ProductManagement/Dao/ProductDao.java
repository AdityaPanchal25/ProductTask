package company.com.ProductManagement.Dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import company.com.ProductManagement.config.Config;
import company.com.ProductManagement.model.Product;

@Repository
public class ProductDao {

	@Autowired
	Config cfg;
	
	public Product getProducts(String name) {
		Session ses = cfg.getSession();
		Product p1 = ses.load(Product.class,name);
		ses.close();
		return p1;
	}
	
	
	public List<Product> getAllProducts(){
		Session ses = cfg.getSession();
		Criteria cr = ses.createCriteria(Product.class);
		List list = cr.list();
		ses.close();
		return list;
		
	}
	
}
